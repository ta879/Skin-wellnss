import React from 'react';

function App() {
  return <div>Welcome to Skin Wellness Tracker</div>;
}

export default App;